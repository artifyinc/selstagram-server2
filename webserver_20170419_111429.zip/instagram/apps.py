from django.apps import AppConfig


class InstagramConfig(AppConfig):
    name = 'instagram'
